import React, { useEffect, useState } from "react";
import TableView from "./components/TableView";
import api from "./Api";
type dataFormate = { userId: number; id: number; title: string; body: string };

function App() {
  const [value, chageValue] = useState<dataFormate[]>([]);

  useEffect(() => {
    const getValue = async () => {
      await api
        .valueGet()
        .then((result) => {
          return result.json();
        })
        .then((res) => {
          chageValue(res);
        });
    };
    getValue();
  }, []);
  return (
    <div style={{ padding: "40px" }}>
      {value.length > 0 ? <TableView data={value} /> : null}
    </div>
  );
}

export default App;
